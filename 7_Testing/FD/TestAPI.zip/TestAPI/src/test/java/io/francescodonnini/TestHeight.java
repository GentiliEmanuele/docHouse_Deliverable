// francesco donnini
package io.francescodonnini;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.Objects;

class TestHeight {
    private static final String DRIVER_PROPERTY = "webdriver.chrome.driver";
    private static final String DRIVER_PATH = "chromedriver.exe";
    private WebDriver driver;

    @BeforeEach
    void setup() {
        System.setProperty(DRIVER_PROPERTY, Objects.requireNonNull(getClass().getResource(DRIVER_PATH)).getPath());
        driver = new ChromeDriver();
        driver.get("https://it.wikipedia.org/wiki/Michael_Jordan");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

    @Test
    void testHeight() {
        WebElement heightRow = driver.findElement(By.xpath("//*[@class=\"sinottico\"]//tr/th[contains(text(), \"Altezza\")]//../td"));
        String rowText = heightRow.getText();
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < rowText.length() && Character.isDigit(rowText.charAt(i)); i++) {
            s.append(rowText.charAt(i));
        }
        Assertions.assertEquals(198, Integer.valueOf(s.toString()));
    }

    @AfterEach
    void close() {
        driver.close();
    }
}