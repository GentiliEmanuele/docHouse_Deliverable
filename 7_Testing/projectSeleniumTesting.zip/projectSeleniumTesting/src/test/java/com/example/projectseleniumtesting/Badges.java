package com.example.projectseleniumtesting;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static com.codeborne.selenide.Selenide.$;

// page_url = https://www.jetbrains.com/
public class Badges {

    public int getRomaBadges() {
        WebDriverManager.chromedriver().setup();
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://it.wikipedia.org/wiki/Associazione_Sportiva_Roma");
        WebElement webBadges = driver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[1]/table[1]/tbody/tr[24]/td"));
        int badges = Integer.valueOf(webBadges.getText());
        driver.close();
        return badges;
    }

    public int getLazioBadges() {
        WebDriverManager.chromedriver().setup();
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://it.wikipedia.org/wiki/Societ%C3%A0_Sportiva_Lazio");
        WebElement webBadges = driver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[1]/table[1]/tbody/tr[22]/td"));
        int badges = Integer.valueOf(webBadges.getText());
        driver.close();
        return badges;
    }

    public static void main(String args[]) throws InterruptedException {

    }
}
