package com.example.projectseleniumtesting;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;


class BadgesTest {
    //Gentili Emanuele
    @Test
    void badgesTest() {
        Badges badges = new Badges();
        int asrBadges = badges.getRomaBadges();
        int sslBadges = badges.getLazioBadges();
        assertTrue(asrBadges > sslBadges);
    }
}
